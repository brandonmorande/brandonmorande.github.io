## ---------------------------
## Title: SOC 403 Data Workshop
## Subtitle: Web Searches and Analysis in R
## Author: Brandon Morande, UW
## Last Edited: 2/2/2025
## ---------------------------

## Set up ----

# Clean environment
rm(list = ls())

# # Install packages
# install.packages("readr")  # To read in datasets
# install.packages("tidyverse")  # To clean, subset, and transform data
# install.packages("tidycensus")  # To query US Census data
# install.packages("tigris")  # To load Census geographies
# install.packages("ggplot2")  # To create graphics
# install.packages("ggthemes")  # To add extra customization for graphics
# install.packages("ggspatial")  # For different map backgrounds
# install.packages("prettymapr")  # For different map backgrounds
# install.packages("kableExtra")  # To format nice tables
# install.packages("webshot2")  # For saving kable tables
# install.packages("sf")  # For spatial data and analysis
# install.packages("units")  # For converting units

# Load packages
library(readr)
library(tidyverse)
library(tidycensus)
library(tigris)
library(ggplot2)
library(ggspatial)
library(prettymapr)
library(ggthemes)
library(kableExtra)
library(webshot2)
library(sf)
library(units)

# To use tigris to get Census geographies
options(tigris_use_cache = TRUE)


## Load and clean restroom data ----

# Load data from the "data" folder within working your directory
restrooms <- read_csv("data/restrooms.csv")

# View first lines of df
head(restrooms)

# Keep needed columns
restrooms <- restrooms |>
  select(c(OBJECTID,
           `Park Name`,
           `Facility Name`,
           `Open to Public (AMWO)`,
           `Season (AMWO)`,
           `Hours Open (AMWO)`,
           `Latitude (AMWO)`,
           `Longitude (AMWO)`
           )
         )

# Filter to only include public restrooms
restrooms <- restrooms |>
  filter(`Open to Public (AMWO)` == "YES")  # Use two equal signs for specifying a value

# See if there is missing (NA) data
colSums(is.na(restrooms))

# Remove observations with missing coordinate data
restrooms <- restrooms |>
  filter(!is.na(`Latitude (AMWO)`),  # Remove rows where Latitude is NA
         !is.na(`Longitude (AMWO)`))


## Create a special features (sf) object ----

# Convert new spatial object called "restrooms_sf"
restrooms_sf <- st_as_sf(restrooms,
                     coords = c("Longitude (AMWO)", "Latitude (AMWO)"),
                     crs = 4269,  # Common CRS for lat/lon in North America
                     remove = FALSE)  # Setting remove to FALSE keeps the lon/lat columns

# Check CRS
st_crs(restrooms_sf)
 
# If incorrect, transform to appropriate projection
restrooms_sf <- st_transform(restrooms_sf, crs = 6596)


## Load and clean light rail station data ----

# Check list of layers in gpkg
st_layers("data/light_rail_stations.gpkg")

# Read in the file
stations <- read_sf("data/light_rail_stations.gpkg", layer = "Light_Rail_Stations")

# Check CRS
st_crs(stations)
# EPSG:2926, NAD83(HARN) State Plane Washington North (ftUS) is also common for Seattle

# Transform CRS
stations <- st_transform(stations, crs = 6596)

# Keep current stations and needed columns
stations <- stations |>
  filter(STATION %in% c("Capitol Hill",  # You may need to use %in% when choosing multiple values
                   "Westlake",
                   "International District / Chinatown")
         )|>
  select(c(STATION,
           SHAPE))


## Link restrooms to stations ----

# Specify buffer distance
distance <- 0.25 * 1609.34  # 0.25 miles in meters

# Create radius polygons
stations_buffer <- st_buffer(stations,
                             dist = distance)

# Match restrooms to stations buffer (for later tables)
stations_restrooms <- stations_buffer |>
  st_join(restrooms_sf,
          join = st_intersects)

# Match stations to restrooms (for later mapping)
restrooms_sf <- restrooms_sf |>
  st_join(stations_buffer,
          join = st_intersects)


## Calculate statistics for restrooms ---- 

# Create a df of restroom counts
restrooms_count <- stations_restrooms |>
  # Group by station
  group_by(STATION) |>
  # Sum up the restroom rows that aren't NA
  summarize(Count = sum(!is.na(`Facility Name`))) |>
  # Remove the geometry column
  st_drop_geometry()

# Construct table with kable 
restrooms_table <- knitr::kable(restrooms_count,
             row.names = FALSE,  # Remove numbers in front of rows
             col.name = c("Station", "Count"),  # Name the columns
             caption = "Number of Public Restrooms Within .25 miles")

# Print table
restrooms_table


# Load and clean parks data ----

# Check list of layers in gpkg
st_layers("data/parks.gpkg")

# Read in the file
parks <- read_sf("data/parks.gpkg", layer = "Parks_Boundary__outline_")

# Check CRS
st_crs(parks) # EPSG:2926

# Transform CRS
parks <- st_transform(parks, crs = 6596)

# Select needed park columns
parks <- parks |>
  select(c(NAME, SHAPE))

# Match parks to stations (for tables)
stations_parks <- stations_buffer |>
  st_join(parks,
          join = st_intersects)

# Match stations to parks (for mapping)
parks <- parks |>
  st_join(stations_buffer,
          join = st_intersects)


## Calculate statistics for parks ----

# Create df of park counts
parks_count <- stations_parks |>
  group_by(STATION) |>
  summarize(Count = sum(!is.na(`NAME`))) |>
  st_drop_geometry()

# Construct table with kable 
parks_table <- knitr::kable(parks_count,
             row.names = FALSE,
             col.name = c("Station", "Count"),
             caption = "Number of Public Parks Within .25 miles")

# Print table
parks_table


## Load Census data ----

# # Set and save Census API key (Not always needed)
# census_api_key("your_api_key_here", install = TRUE, overwrite = TRUE)

# Request decennial population data
block_pop <- get_decennial(geography = "block",
                           state = "WA",
                           county = "King",
                           year = 2020,
                           geometry = TRUE,  # To get block geometry
                           #table = "P1",  # To download all household/demographic data
                           variables = "P1_001N"
                           )

# Transform crs
block_pop <- st_transform(block_pop, crs = 6596)

# Calculate area
block_pop <- block_pop |>
  mutate(area_sqmile = set_units(st_area(geometry), "mile^2"))


## Link blocks to stations ----

# Match block populations to stations
stations_block_pop <- stations_buffer |>
  st_join(block_pop,
          join = st_intersects)


## Calculate population statistics ----

# Calculate population size and density
stations_total_pop <- stations_block_pop |>
  group_by(STATION) |>
  # Sum the block population and area values by station
  summarize(tot_pop = sum(value),
            tot_area = sum(area_sqmile)) |>
  # Create new density column
  mutate(pop_dens = tot_pop/tot_area) |>
  st_drop_geometry()

# Create table
pop_table <- stations_total_pop |>
  # Drop units from values using as.numeric
  mutate(tot_area = round(as.numeric(tot_area), 2),  # Round to two places
         pop_dens = round(as.numeric(pop_dens))) |>  # Remove decimals
  knitr::kable(
             row.names = FALSE,
             col.name = c("Station", "Size", "Area (sq mile)", "Density"),
             caption = "Surrounding Population Size and Density")

# Print table
pop_table


## Create maps with OSM background ----

# Map of Capitol Hill
(capitol_hill_map <- ggplot() +
  # Add OSM background
  annotation_map_tile(type = "osm",
                      zoom = 16) +  # Can change zoom of the map
  # Add station buffer zone
  geom_sf(data = subset(stations_buffer, STATION == "Capitol Hill"), 
          aes(geometry = SHAPE), 
          color = "darkred", # Color the boundary
          linewidth = 0.5,  # Set width of line
          fill = "red",  # Color in circle
          alpha = 0.1) +  # Make circle transparent to see map background
  # Add station point
  geom_sf(data = subset(stations, STATION == "Capitol Hill"), 
          aes(geometry = SHAPE),
          color = "blue",
          size = 4) +  # Change size of point
  # Add a title
  labs(title = "Capitol Hill Station") +
  # Remove axes
  theme(
    axis.text.x = element_blank(),
    axis.ticks.x = element_blank(),
    axis.text.y = element_blank(),
    axis.ticks.y = element_blank()
    )
)

# Add parks and restrooms to map
(capitol_hill_map <-
  # Start with existing map
  capitol_hill_map +
  # Add items
  geom_sf(data = subset(parks, STATION == "Capitol Hill"),
          aes(geometry = SHAPE,
              color = "Park"),  # Add parks to color legend
          fill = "green4",  # Fill polygon
          alpha = 0.5) +
  geom_sf(data = subset(restrooms_sf, STATION == "Capitol Hill"),
          aes(geometry = geometry,
              color = "Restroom"),  # Add restrooms to color legend
          size = 4, shape = 18) +
  # Add a legend and specify colors
  scale_color_manual(name = NULL,  # Remove legend title
                     values = c("Park" = "green4",
                                "Restroom" = "darkgreen")) + 
  # Customize the legend
  guides(color = guide_legend(override.aes = list(size = 4,  # Increase size of points
                                                  fill = "green4")))  # Fill polygon
)


# Save map, specifying file path, dimensions, and resolution
ggsave(plot = capitol_hill_map, "figures/capitol_hill_map.pdf",
       width = 6, height = 6, dpi = 300)


## Create maps with Census blocks background ----

# Download census block geography
block_geo <- blocks(state = "WA", county = "King", year = 2020, class = "sf")


# Map of Capitol Hill
(capitol_hill_map_simple <- ggplot() +
   # Add Census boundaries
   geom_sf(data = block_geo, aes(geometry = geometry)) +
   # Add station buffer zone
   geom_sf(data = subset(stations_buffer, STATION == "Capitol Hill"), 
          aes(geometry = SHAPE), color = "darkred", linewidth = 0.5,
          fill = "red", alpha = 0.1) +
   # Add station point
   geom_sf(data = subset(stations, STATION == "Capitol Hill"), 
          aes(geometry = SHAPE, color = "Station"), size = 4) +
   # Add parks
   geom_sf(data = subset(parks, STATION == "Capitol Hill"),
          aes(geometry = SHAPE, color = "Park"),
          fill = "green4", alpha = 0.5) +
   # Add park name
   geom_text(data = subset(parks, STATION == "Capitol Hill"),
             aes(x = st_coordinates(st_centroid(SHAPE))[, 1],  # Extract x-coords of shape center
                y = st_coordinates(st_centroid(SHAPE))[, 2],  # Extract y-coords
                label = NAME),
             size = 2) +
   # Add restrooms
   geom_sf(data = subset(restrooms_sf, STATION == "Capitol Hill"),
          aes(geometry = geometry, color = "Restroom"),
          size = 4, shape = 18) +
  # Add legend
  scale_color_manual(name = NULL,
                     values = c("Station" = "blue",
                                "Park" = "green4",
                                "Restroom" = "darkgreen")) + 
  # Customize legend
  guides(color = guide_legend(override.aes = list(size = 4, fill = "green4"))) +
  # Add a title
  labs(title = "Capitol Hill Station") +
  # Remove axes
  theme(
    axis.title = element_blank(),
    axis.text.x = element_blank(),
    axis.ticks.x = element_blank(),
    axis.text.y = element_blank(),
    axis.ticks.y = element_blank()
    ) +
  # Zoom into Capitol Hill
  coord_sf(xlim = c(-122.328, -122.312), ylim = c(47.614, 47.624), expand = FALSE)
)

# Save plot
ggsave(plot = capitol_hill_map_simple, "figures/capitol_hill_map_simple.pdf",
       width = 6, height = 6, dpi = 300)


